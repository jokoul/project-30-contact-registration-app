
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h2>Contact Information</h2>
        </div>
        <div class="card-body">
            <h5>Name: <?php echo e($contact->name); ?></h5>
            <p>Address: <?php echo e($contact->address); ?></p>
            <p>Mobile: <?php echo e($contact->mobile); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('contacts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\joank\Documents\PROJET FORMATION DEVELOPPEUR WEB\COURS VIDEO\LANGAGES FRAMEWORKS LIBRAIRIES\LARAVEL\tutus funny\laravel 9 crud step by step\contact-register\resources\views/contacts/show.blade.php ENDPATH**/ ?>