
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h2>Create Contact</h2>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(url('/contacts/')); ?>">
                <?php echo e(csrf_field()); ?>

            
                <label class="mt-2" for="name">Name: </label><br>
                <input type="text" id="name" name="name" class="form-control"><br>
                <label class="mt-2" for="address">Address: </label><br>
                <input type="text" id="address" name="address" class="form-control"><br>
                <label class="mt-2" for="mobile">Mobile: </label><br>
                <input type="text" id="mobile" name="mobile" class="form-control"><br>
                <input type="submit" name="submit" value="Save" class="btn btn-success mt-3"><br>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('contacts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\joank\Documents\PROJET FORMATION DEVELOPPEUR WEB\COURS VIDEO\LANGAGES FRAMEWORKS LIBRAIRIES\LARAVEL\tutus funny\laravel 9 crud step by step\contact-register\resources\views/contacts/create.blade.php ENDPATH**/ ?>